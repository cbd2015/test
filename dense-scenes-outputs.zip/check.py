from pathlib import Path
import json, hashlib
import numpy as np

root = Path(__file__).resolve().parent
d = json.loads((root / 'measurements.json').read_text())
for key, filename in [('food','dining_table.png'),('crowd','lots_of_people.jpeg')]:
    rec = d[key]
    assert hashlib.sha256((root / 'scenes' / filename).read_bytes()).hexdigest() == rec['source_sha256']
    w,h = rec['size']
    box = np.rint(np.array(d['method_details']['regions_xyxy_normalized'][key])*[w,h,w,h])
    for method in ('gpt','qwen','clip'):
        bb = np.array(rec[method])
        masks = np.load(root / 'masks' / f'{key}-{method}.npz')['masks']
        assert masks.shape == (len(bb),h,w)
        x = (bb[:,0]+bb[:,2])/2
        y = (bb[:,1]+bb[:,3])/2
        cnt = ((x>=box[0]) & (x<box[2]) & (y>=box[1]) & (y<box[3])).sum()
        print(key,method,'whole',len(bb),'region',cnt)
a=np.load(root/'masks/food-gpt.npz')['masks'][0]
b=np.load(root/'masks/food-qwen.npz')['masks'][0]
iou=(a & b).sum()/(a | b).sum()
assert round(iou,3)==0.907
print('upper-left scallop: inter-prediction mask IoU',round(iou,3))
