import hashlib,json
from pathlib import Path
import os, sys
import numpy as np
import torch
from torchvision import transforms
from torchvision.ops import nms
from PIL import Image,ImageOps
from ultralytics import YOLOE
import clip
from clip.model import build_model
from mobile_sam import SamAutomaticMaskGenerator,sam_model_registry

roots=Path(__file__).resolve().parent
assets=(roots/'weights').resolve()
old=assets
os.chdir(assets)
torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.manual_seed(0)
cfg=json.loads((roots/'cases.json').read_text())
inputs=roots/'originals'; outputs=roots/'outputs';outputs.mkdir(exist_ok=True)
files={c['id']:next((p for p in sorted(inputs.glob(c['id']+'.*')) if p.suffix.lower() in ['.jpg','.jpeg','.png','.webp']),None) for c in cfg}
missing=[k for k,v in files.items() if v is None]
if len(missing)==len(cfg):sys.exit("No exact source images available")
cfg=[c for c in cfg if files[c['id']] is not None]
yolo=YOLOE(str(assets/'yoloe-v8l-seg.pt'))
sam=sam_model_registry['vit_t'](checkpoint=str(old/'msam.pt')).eval()
gen=SamAutomaticMaskGenerator(sam,points_per_side=24,points_per_batch=32,pred_iou_thresh=.83,stability_score_thresh=.91,box_nms_thresh=.7,crop_n_layers=0,min_mask_region_area=0)
encoder=build_model(torch.load(old/'clip.pt',weights_only=True,map_location='cpu')).float().eval()
prep=transforms.Compose([transforms.Resize(224,interpolation=transforms.InterpolationMode.BICUBIC),transforms.CenterCrop(224),transforms.ToTensor(),transforms.Normalize([.48145466,.4578275,.40821073],[.26862954,.26130258,.27577711])])

def classify(img,phrases):
 w,h=img.size;cand=[];tensors=[]
 for mask in gen.generate(np.asarray(img)):
  x,y,bw,bh=mask['bbox']
  if not (w*h*.0003<=bw*bh<=w*h*.30 and min(bw,bh)>=6):continue
  extra=round(max(bw,bh)*.08)
  crop=img.crop((max(0,x-extra),max(0,y-extra),min(w,x+bw+extra+1),min(h,y+bh+extra+1)))
  tensors.append(prep(crop));cand.append([x,y,min(w,x+bw+1),min(h,y+bh+1)])
 if not cand:return [],[],0
 em=encoder.encode_text(clip.tokenize(phrases));em/=em.norm(dim=-1,keepdim=True)
 scores=[]
 for chunk in torch.stack(tensors).split(12):
  a=encoder.encode_image(chunk);a/=a.norm(dim=-1,keepdim=True)
  scores.extend((encoder.logit_scale.exp()*a@em.T).softmax(-1)[:,0].tolist())
 sel=[i for i,v in enumerate(scores) if v>=.50]
 if not sel:return [],[],len(cand)
 keep=nms(torch.tensor([cand[j] for j in sel],dtype=torch.float32),torch.tensor([scores[j] for j in sel]),.50).tolist()
 out=[sel[i] for i in keep]
 return [cand[i] for i in out],[scores[i] for i in out],len(cand)

with torch.inference_mode():
 for c in cfg:
  k=c['id'];src=files[k];im=ImageOps.exif_transpose(Image.open(src)).convert('RGB')
  w,h=im.size;roi=[round(v*z) for v,z in zip(c['roi'],[w,h,w,h])]
  prompt=c['detector_prompt'];yolo.set_classes([prompt],yolo.get_text_pe([prompt]))
  phrases=['a photo of '+prompt]+c['other_prompts']
  rec=dict(scene=k,source=src.name,sha256=hashlib.sha256(src.read_bytes()).hexdigest(),size=[w,h],region=roi,detector_prompt=prompt,clip_prompts=phrases,views={})
  for view,img in [('full',im),('roi',im.crop(roi))]:
   print(k,view,flush=True)
   r=yolo.predict(img,imgsz=960,conf=.20,iou=.50,max_det=600,device='cpu',verbose=False,save=False)[0].boxes
   bb,sc,num=classify(img,phrases)
   rec['views'][view]={'size':list(img.size),'yoloe':{'xyxy':r.xyxy.cpu().numpy().round(1).tolist(),'scores':r.conf.cpu().tolist()},'openclip':{'xyxy':bb,'scores':sc,'candidate_count':num}}
  (outputs/(k+'.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=1));print(k,'saved',flush=True)
