from pathlib import Path
from PIL import Image,ImageOps
import io,base64,urllib.request as u,json,time,re,math
r=Path(__file__).resolve().parent
dest=r/'qwen-output';dest.mkdir(exist_ok=True)
op=u.build_opener(u.ProxyHandler({}))
for case in json.loads((r/'cases.json').read_text()):
 k=case['id']
 if (dest/(k+'.json')).exists():continue
 f=next((r/'originals').glob(k+'.*'))
 im=ImageOps.exif_transpose(Image.open(f)).convert('RGB');w,h=im.size
 cw,ch=im.size;buf=io.BytesIO();im.save(buf,'PNG')
 prompt=f"Locate every individually visible instance of the following target in this image: {case['detector_prompt']}. Draw one tight bounding box around the visible extent of each instance, including partially visible instances that can be distinguished. Return a JSON array of objects, each with bbox_2d: [x_min, y_min, x_max, y_max]. Use integer coordinates normalized from 0 to 1000 relative to this image. Return [] if no target is visible."
 payload={'messages':[{'role':'user','content':[{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()}},{'type':'text','text':prompt}]}],'temperature':0,'seed':0,'max_tokens':3500,'stream':False}
 request=u.Request('http://127.0.0.1:18086/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 print(k,'begin',flush=True);start=time.monotonic()
 if (dest/(k+'-response.json')).is_file():answer=json.loads((dest/(k+'-response.json')).read_text())
 else:
  with op.open(request,timeout=900) as resp:answer=json.load(resp)
 content=answer['choices'][0]['message']['content']
 (dest/(k+'-response.json')).write_text(json.dumps(answer,ensure_ascii=False,indent=1))
 # Instruct models commonly enclose the JSON in a Markdown fence. Preserve the raw response.
 cleaned=re.sub(r'^\s*```(?:json)?\s*|\s*```\s*$','',content,flags=re.I)
 try:
  parsed=json.loads(cleaned);assert isinstance(parsed,list);partial=False
 except (ValueError,AssertionError):
  # Preserve only complete JSON objects when a response is truncated.
  parsed=[];partial=True
  for item in re.findall(r'\{[^{}]*\}',cleaned):
   try: parsed.append(json.loads(item))
   except ValueError: pass
 boxes=[];rejected=[]
 for obj in parsed:
  b=obj.get('bbox_2d') if isinstance(obj,dict) else obj
  if not isinstance(b,list) or len(b)!=4 or not all(isinstance(x,(int,float)) and math.isfinite(x) for x in b) or b[0]>=b[2] or b[1]>=b[3] or min(b)<0 or max(b)>1000:
   rejected.append(obj);continue
  boxes.append([round(a*z/1000,3) for a,z in zip(b,[cw,ch,cw,ch])])
 row={'source':f.name,'model':'Qwen3-VL-2B-Instruct, ai/qwen3-vl:2B-UD-Q4_K_XL','runtime':'llama.cpp b9000 CPU','view':'full','size':[cw,ch],'prompt':prompt,'temperature':0,'seed':0,'max_tokens':3500,'finish_reason':answer['choices'][0].get('finish_reason'),'partial':partial,'rejected':rejected,'xyxy':boxes}
 (dest/(k+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=1))
 print(k,len(boxes),'boxes, seconds',round(time.monotonic()-start,1),flush=True)
