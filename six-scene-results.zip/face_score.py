from pathlib import Path
import json,csv,numpy as np
from scipy.optimize import linear_sum_assignment
r=Path(__file__).resolve().parent
g=json.loads((r/'gpt-full.json').read_text())['views']['team']['xyxy']
q=json.loads((r/'qwen-output/team.json').read_text())['xyxy']
v=json.loads((r/'full-auto/team.json').read_text())['views']['full']
a=np.array(json.loads((r/'face-reference.json').read_text())['xyxy'])[:,None,:]
d={}
for method,bb in [('GPT',g),('Qwen',q),('YOLOE',v['yoloe']['xyxy']),('OpenCLIP',v['openclip']['xyxy'])]:
 d[method]={'full_box_count':len(bb),'agreement':{}}
 for threshold in [.30,.50]:
  matched=[]
  if bb:
   b=np.array(bb)[None,:,:];inter=np.prod(np.maximum(0,np.minimum(a[:,:,2:],b[:,:,2:])-np.maximum(a[:,:,:2],b[:,:,:2])),axis=2);union=np.prod(a[:,:,2:]-a[:,:,:2],axis=2)+np.prod(b[:,:,2:]-b[:,:,:2],axis=2)-inter
   iou=inter/union;valid=iou>=threshold
   pi,pj=linear_sum_assignment(-(valid*(len(a)+1)+iou))
   matched=[{'reference':int(i),'detection':int(j),'IoU':float(iou[i,j])} for i,j in zip(pi,pj) if valid[i,j]]
  d[method]['agreement'][str(threshold)]=matched
 print(method,[len(val) for val in d[method]['agreement'].values()])
(r/'team-agreement.json').write_text(json.dumps(d,indent=1))
