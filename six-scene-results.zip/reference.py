"""Independent full-frame face proposals for a limited agreement audit, not human ground truth."""
from pathlib import Path
import cv2,numpy as np,json,hashlib
from PIL import Image,ImageDraw
r=Path(__file__).resolve().parent
im=cv2.imread(str(r/'originals/team.png'));h,w=im.shape[:2]
model=cv2.dnn.readNetFromCaffe(str(r/'detector.prototxt'),str(r/'reference.caffemodel'))
# A full-frame input; one pass, no tiles. A fixed threshold is used for every returned face.
model.setInput(cv2.dnn.blobFromImage(im,1,(600,600),(104,177,123),swapRB=False,crop=False))
out=model.forward()[0,0];bb=[];scores=[]
for row in out:
 if float(row[2])<.80:continue
 x1,y1,x2,y2=np.clip(row[3:7],0,1)*[w,h,w,h]
 if x2>x1 and y2>y1:bb.append([round(float(x),2) for x in (x1,y1,x2,y2)]);scores.append(float(row[2]))
audit={'method':'OpenCV ResNet-10 SSD face detector fp16, published weights, one full-frame 600x600 resize, BGR mean (104,177,123), minimum confidence 0.80. These are face detections, serving only as independent reference anchors for visible frontal faces.','weights_url':'https://raw.githubusercontent.com/opencv/opencv_3rdparty/19512576c112aa2c7b6328cb0e8d589a4a90a26d/res10_300x300_ssd_iter_140000_fp16.caffemodel','weights_sha256':hashlib.sha256((r/'reference.caffemodel').read_bytes()).hexdigest(),'prototxt_sha256':hashlib.sha256((r/'detector.prototxt').read_bytes()).hexdigest(),'xyxy':bb,'scores':scores,'size':[w,h]}
(r/'face-reference.json').write_text(json.dumps(audit,indent=1))
a=Image.fromarray(cv2.cvtColor(im,cv2.COLOR_BGR2RGB)).resize((w*2,h*2))
d=ImageDraw.Draw(a)
for j,bb in enumerate(bb):
 l,t,r1,b1=(x*2 for x in bb);d.rectangle((l,t,r1,b1),outline='#fced76',width=2);d.text((l,t-12),str(j+1),fill='#fced76',stroke_fill='black',stroke_width=1)
a.save(r/'face-reference-review.jpg',quality=95)
print(len(scores))
