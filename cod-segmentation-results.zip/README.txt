本结果包对应申请书图2。
来源为 Fan D-P, Ji G-P, Sun G, et al. Camouflaged Object Detection, CVPR 2020。作者公开中文版第2页图3。下列 DOI 指向原论文，GitHub 固定版指向采用的图件。输入为作者 PDF 内嵌的 RGB 图像对象，无标题文字。采用图版中“比目鱼”和“蝈蝈儿（螽斯）”的彩色实例掩膜，以任一颜色通道 > 127 得到二值参考掩膜。两对图像及标注各自同尺寸，无须插值配准。适用于学术交流。来源版本、PDF 对象号见 bench/sources.json。
https://doi.org/10.1109/CVPR42600.2020.00285
https://github.com/DengPingFan/DengPingFan.github.io/blob/a3800f65437c611fdf103df14d570188d08498b5/papers/%5B2020%5D%5BCVPR%5DCOD_Chinese.pdf

试验为两幅图像的定性诊断，没有对全数据集估计平均精度。两种动物使用相同的任务语义。推理输入不含人工框、人工掩膜或动物类别名。Qwen3-VL-2B-Instruct 量化（2B-UD-Q4_K_XL）以 llama.cpp b9000 本地执行，CPU，4096 上下文，4 线程，温度 0、seed 0，最多生成 1000 tokens。相同原图分别询问单一动物的可见外接框和顺时针轮廓，英文完整提示见 metrics.json。对直接坐标，解析返回的成对数值，按图像宽高映射后以直线连接并栅格化。比目鱼的有效响应含四个不同顶点，少于请求的 8–24 个。螽斯的轮廓响应达到长度上限，序列存在越界且未完成，不生成多边形、不计该项 IoU。原始回复完整保留。

Qwen→SAM：将 Qwen 返回的归一化框转为原图像素坐标，交给 MobileSAM TinyViT 的 SamPredictor，multimask_output=False，不人工修框。SAM→CLIP：同一 MobileSAM（24×24 点、pred_iou_thresh .83、stability_score_thresh .91、box_nms_thresh .70）产生掩膜，候选框最短边至少 6 像素。裁取带 8% 上下文的候选区域，送入 OpenCLIP ViT-B/32 QuickGELU（LAION-400M e32）。用目标与背景两条提示计算相对得分，因每图查询一只动物，取排名第一的原始候选掩膜。候选框、所有分数及所选索引保存在 *-clip-metrics.json。这里的 SAM、CLIP 分别是 MobileSAM 和 OpenCLIP。
青绿 = 预测与人工前景相交，橙色 = 漏分，紫色 = 误分。各项指标在原图网格计算：IoU=TP/(TP+FP+FN)，Dice=2TP/(2TP+FP+FN)。角签和半透明着色仅用于排版。分类误差图的编辑图层在 PPT 中，定量分析使用独立二值 PNG。

复现：下载作者版 PDF 命名为 cod-author.pdf；安装 PyMuPDF / Pillow / NumPy 后运行 extract.py。在本地准备 PyTorch 2.8、torchvision 0.23、OpenAI CLIP、MobileSAM。环境变量 OPENCLIP_CHECKPOINT 和 MOBILE_SAM_CHECKPOINT 指向对应 .pt 权重。用 llama.cpp b9000 运行：
llama-server -m LANGUAGE.gguf --mmproj VISION.gguf -t 4 -tb 4 --host 127.0.0.1 --port 18086 -c 4096 -np 1 --jinja --no-warmup
在空的 bench 输出目录（仅保留提取的输入和参考图）运行 python cod_infer.py 和 python clip_cod.py 可重算结果。有已保存的 Qwen 响应时，脚本读取归档响应，即可复核掩膜与计分。权重校验值见 weights.json。
