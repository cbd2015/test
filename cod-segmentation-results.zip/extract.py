import fitz,io,numpy as np,json,hashlib
from PIL import Image
from pathlib import Path
r=Path(__file__).resolve().parent;d=fitz.open(r/'cod-author.pdf')
p={}
for k,a,b in [('flounder',4,2),('cricket',17,10)]:
 for ref,what in [(a,'rgb'),(b,'gt')]:
  img=Image.open(io.BytesIO(d.extract_image(ref)['image'])).convert('RGB');arr=np.array(img)
  if what=='gt':img=Image.fromarray((arr.max(axis=2)>127).astype(np.uint8)*255)
  img.save(r/'bench'/(k+'-'+what+'.png'))
 p[k]={'paper':'Fan et al. Camouflaged Object Detection. CVPR 2020. Chinese author version, PDF p.2, Fig.3','repository':'https://github.com/DengPingFan/DengPingFan.github.io','revision':'a3800f65437c611fdf103df14d570188d08498b5','file':'papers/[2020][CVPR]COD_Chinese.pdf','image_xref':a,'annotated_mask_xref':b,'reference_mask_rule':'maximum of the three annotation color channels > 127','size':list(img.size)}
(r/'bench'/'sources.json').write_text(json.dumps(p,indent=2))
