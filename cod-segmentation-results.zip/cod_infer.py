import json,io,base64,urllib.request as u,re,os
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,torch,hashlib
from mobile_sam import SamPredictor,sam_model_registry
r=Path(__file__).resolve().parent;b=r/'bench'
sam=SamPredictor(sam_model_registry['vit_t'](checkpoint=os.environ.get('MOBILE_SAM_CHECKPOINT','/tmp/dense-real/msam.pt')).eval())
torch.set_num_threads(4);torch.set_num_interop_threads(1)
op=u.build_opener(u.ProxyHandler({}))
prompts={
'box':"Locate the single camouflaged animal in this photograph. Return one tight bounding box around its visible extent as JSON: {\"bbox_2d\":[xmin,ymin,xmax,ymax]}. Use integer x and y coordinates normalized from 0 to 1000. Return no other text.",
'polygon':"Segment the single camouflaged animal in this photograph. Trace the outer contour of the visible animal clockwise, using between 8 and 24 vertices to follow its silhouette. Return JSON only: {\"polygon\":[[x1,y1],[x2,y2],...]}. Use integer coordinates normalized from 0 to 1000, x from left to right, y from top to bottom. Close the polygon implicitly."}
for k in ['flounder','cricket']:
 im=Image.open(b/(k+'-rgb.png')).convert('RGB');W,H=im.size;pix=io.BytesIO();im.save(pix,'PNG')
 out={'sample':k,'size':[W,H],'model':'Qwen3-VL-2B-Instruct (2B-UD-Q4_K_XL), llama.cpp b9000','temperature':0,'seed':0,'pixel_decoder':'MobileSAM TinyViT, box prompt, multimask_output=False','prompts':prompts}
 parsed={}
 for task,prompt in prompts.items():
  raw=b/(k+'-'+task+'-response.json')
  if not raw.exists():
   inp={'messages':[{'role':'user','content':[{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(pix.getvalue()).decode()}},{'type':'text','text':prompt}]}],'temperature':0,'seed':0,'max_tokens':1000}
   req=u.Request('http://127.0.0.1:18086/v1/chat/completions',data=json.dumps(inp).encode(),headers={'Content-Type':'application/json'})
   raw.write_text(json.dumps(json.load(op.open(req,timeout=420)),ensure_ascii=False,indent=1))
  resp=json.loads(raw.read_text());st=resp['choices'][0]['message']['content'];print(k,task,resp['choices'][0]['finish_reason'],st[:500],flush=True)
  st=re.sub(r'^\s*```(?:json)?\s*|\s*```\s*$','',st,flags=re.I)
  if resp['choices'][0]['finish_reason']=='length' and task=='polygon':
   parsed[task]=None;continue
  payload=json.loads(st);payload=payload[0] if isinstance(payload,list) and isinstance(payload[0],dict) else payload
  parsed[task]=payload['bbox_2d' if task=='box' else 'polygon'] if isinstance(payload,dict) else payload
 box=np.array(parsed['box'],float)/1000*[W,H,W,H];assert len(box)==4 and box[2]>box[0] and box[3]>box[1]
 if parsed['polygon'] is not None:
  pts=np.array(parsed['polygon'],float).reshape(-1,2);assert len(pts)>=3 and pts.min()>=0 and pts.max()<=1000
  # Polygon vertices on the inclusive pixel grid.
  pts=np.rint(pts/1000*[W-1,H-1]).astype(int)
  polygon=Image.new('L',im.size);ImageDraw.Draw(polygon).polygon([tuple(z) for z in pts],fill=255);polygon.save(b/(k+'-polygon.png'))
 with torch.inference_mode():
  sam.set_image(np.array(im));m,score,_=sam.predict(box=box,multimask_output=False)
 Image.fromarray(np.uint8(m[0])*255).save(b/(k+'-sam.png'))
 out.update({'raw_geometry_normalized':parsed,'sam_box_pixels':box.tolist(),'sam_predicted_quality':float(score[0])})
 gt=np.array(Image.open(b/(k+'-gt.png')))>0
 for name in ['polygon','sam']:
  if name=='polygon' and parsed['polygon'] is None:
   out[name]={'status':'truncated, no usable closed polygon'};continue
  a=np.array(Image.open(b/(k+'-'+name+'.png')))>0
  tp=int(np.count_nonzero(a&gt));fp=int(np.count_nonzero(a&~gt));fn=int(np.count_nonzero(~a&gt))
  out[name]={'tp':tp,'fp':fp,'fn':fn,'IoU':tp/(tp+fp+fn),'Dice':2*tp/(2*tp+fp+fn)}
 (b/(k+'-metrics.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2));print(k,out['polygon'],out['sam'],flush=True)
