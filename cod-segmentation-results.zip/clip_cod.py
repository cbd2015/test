from pathlib import Path
import os,json
import numpy as np, torch
from torchvision import transforms
from PIL import Image
import clip
from clip.model import build_model
from mobile_sam import sam_model_registry,SamAutomaticMaskGenerator
R=Path(__file__).resolve().parent;B=R/'bench'
torch.set_num_threads(4);torch.set_num_interop_threads(1)
m=build_model(torch.load(os.environ.get('OPENCLIP_CHECKPOINT','/tmp/dense-real/clip.pt'),map_location='cpu',weights_only=True)).float().eval()
sam=sam_model_registry['vit_t'](checkpoint=os.environ.get('MOBILE_SAM_CHECKPOINT','/tmp/dense-real/msam.pt')).eval()
gen=SamAutomaticMaskGenerator(sam,points_per_side=24,points_per_batch=32,pred_iou_thresh=.83,stability_score_thresh=.91,box_nms_thresh=.7,crop_n_layers=0,min_mask_region_area=0)
prep=transforms.Compose([transforms.Resize(224,interpolation=transforms.InterpolationMode.BICUBIC),transforms.CenterCrop(224),transforms.ToTensor(),transforms.Normalize([.48145466,.4578275,.40821073],[.26862954,.26130258,.27577711])])
texts=['a photo of a camouflaged animal','a photo of the natural background without an animal']
with torch.inference_mode():
 tx=m.encode_text(clip.tokenize(texts));tx/=tx.norm(dim=-1,keepdim=True)
 for k in ['flounder','cricket']:
  im=Image.open(B/(k+'-rgb.png')).convert('RGB');w,h=im.size;ms=gen.generate(np.asarray(im));boxes=[];ims=[];masks=[]
  for q in ms:
   x,y,bw,bh=q['bbox']
   if min(bw,bh)<6:continue
   e=round(.08*max(bw,bh));bb=(max(0,x-e),max(0,y-e),min(w,x+bw+1+e),min(h,y+bh+1+e))
   ims.append(prep(im.crop(bb)));boxes.append([x,y,bw,bh]);masks.append(q['segmentation'])
  scores=[]
  for c in torch.stack(ims).split(12):
   f=m.encode_image(c);f/=f.norm(dim=-1,keepdim=True);scores+=(m.logit_scale.exp()*f@tx.T).softmax(-1)[:,0].tolist()
  i=int(np.argmax(scores));a=masks[i];Image.fromarray(np.uint8(a)*255).save(B/(k+'-clip.png'))
  gt=np.array(Image.open(B/(k+'-gt.png')))>0;tp=int(np.count_nonzero(a&gt));fp=int(np.count_nonzero(a&~gt));fn=int(np.count_nonzero(~a&gt))
  o={'sample':k,'prompts':texts,'candidate_count':len(scores),'index':i,'all_boxes_xywh':boxes,'all_scores':scores,'tp':tp,'fp':fp,'fn':fn,'IoU':tp/(tp+fp+fn),'Dice':2*tp/(2*tp+fp+fn)}
  (B/(k+'-clip-metrics.json')).write_text(json.dumps(o,indent=1));print(k,len(scores),o['IoU'],flush=True)
